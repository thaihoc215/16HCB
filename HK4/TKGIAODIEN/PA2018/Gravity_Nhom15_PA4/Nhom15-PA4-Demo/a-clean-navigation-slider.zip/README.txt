A Pen created at CodePen.io. You can find this one at http://codepen.io/Roemerdt/pen/NxPjVB.

 This is a very clean navigation with a cool slider