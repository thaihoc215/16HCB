1. Trước khi chạy chương trình, chạy file script.sql để tạo csdl
2. Thay đổi đường dẫn ConnectionString trong file App.config
connectionString hiện tại : connectionString="Data Source=.;Initial Catalog=QLHocSinh;Integrated Security=True" providerName="System.Data.SqlClient"