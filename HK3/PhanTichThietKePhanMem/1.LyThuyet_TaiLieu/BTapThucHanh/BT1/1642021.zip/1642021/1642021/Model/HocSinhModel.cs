﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1642021.Model
{
    public class HocSinhModel
    {
        public int MaHS { get; set; }
        public String TenHS { get; set; }
        public DateTime NgaySinh { get; set; }
        public String SDT { get; set; }
        public String DiaChi { get; set; }

        public HocSinhModel()
        {

        }
    }
}
