package com.mygdx.states;

public class ModeMenu {

}
