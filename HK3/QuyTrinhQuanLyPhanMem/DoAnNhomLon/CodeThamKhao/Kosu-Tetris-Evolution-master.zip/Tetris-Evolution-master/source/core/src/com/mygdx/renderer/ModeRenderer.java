package com.mygdx.renderer;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.mygdx.modes.Mode;

public class ModeRenderer {
	
	Mode mode;
	
	public ModeRenderer(Mode mode){
		this.mode = mode;
	}
	
	public void draw(Batch batch){
		
	}
}
