package com.mygdx.test;

import com.mygdx.tools.InvertXY;

public class InvertTest {
	public static void main(String[] args){
		System.out.print(Integer.valueOf(InvertXY.invert(100, 500, 0)));
	}
}
